<div align="center">
  <h1>♪ TikTok Account Creator (Mobil Api)</h1>
</div>

# NOTE
Some scammers on Telegram are trying to scam you by getting anydesk registration, do not trust them. I only use the @hiddenexe telegram address.

# Usage:

- register kopechka.com & create api key
- pip install -r requirements.txt
- Add api key to main.py & py main.py
- enter thread count
- enjoy!

# Features:

- Full Mobil Api (1233)
- Device Registration (paid)
- No Third Party Apis
- Full Requests
- Need Proxies
- Captcha Solver
- X-Argus, X-Ladon, X-Gorgon, X-Khronos Included
 
# Contact:

Discord: https://discord.com/users/1213658859185381387
<br>
Telegram: @hiddenexe
<br>
Gmail: hidden4xe@gmail.com
 
# Preview:

<div align="center">
      <a href="https://www.youtube.com/watch?v=XfXPpIJbElg">
         <img src="https://png.pngtree.com/png-vector/20221018/ourmid/pngtree-youtube-social-media-round-icon-png-image_6315993.png" style="width:20%;">
      </a>

</div>

